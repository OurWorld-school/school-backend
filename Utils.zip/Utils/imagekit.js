const ImageKit = require("imagekit");

const imagekit = new ImageKit({
  publicKey: "public_2l8Ns3gZs/9LB2S87S4pHbj5Fhw=",
  privateKey: "private_u8wxUEdWBN3fDVMqkskNlybIq5M=",
  urlEndpoint: "https://ik.imagekit.io/ourworldschool",
});

module.exports = imagekit;
